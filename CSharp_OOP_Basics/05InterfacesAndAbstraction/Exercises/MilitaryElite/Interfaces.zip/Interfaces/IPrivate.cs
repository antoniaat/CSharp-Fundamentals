﻿public interface IPrivate
{
    decimal Salary { get; set; }
}
