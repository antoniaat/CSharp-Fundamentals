﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Launcher
{
    public class StartUp
    {
        
        public static void Main()
        {
            var draftmanager = new DraftManager();

            string command;
            while ((command = Console.ReadLine()) != "Shutdown")
            {
                var tokens = command
                    .Split(new [] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                    .ToList();

                CheckCommand(tokens, draftmanager);
            }

           Console.WriteLine(draftmanager.ShutDown());
        }

        private static void CheckCommand(List<string> tokens, DraftManager draftmanager)
        {
            if (tokens[0] == "RegisterHarvester" && tokens[1] == "Sonic")
            {
               

                draftmanager.RegisterHarvester(tokens);
            }
            else if (tokens[0] == "RegisterHarvester")
            {
                var type = tokens[1];
                var id = tokens[2];
                var oreOutput = tokens[3];
                var energyRequirement = tokens[4];
            }
            else if (tokens[0] == "RegisterProvider")
            {
                var type = tokens[1];
                var id = tokens[2];
                var energyOutput = tokens[3];
            }
            else if (tokens[0] == "Day")
            {

            }
            else if (tokens[0] == "Mode")
            {
                var mode = tokens[1];
            }
            else if (tokens[0] == "Check")
            {
                var id = tokens[1];
            }
        }
    }
}
