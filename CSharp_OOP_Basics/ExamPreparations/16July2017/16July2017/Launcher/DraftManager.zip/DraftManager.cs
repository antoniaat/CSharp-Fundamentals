﻿using System.Collections.Generic;

public class DraftManager
{
    List<Harvester> harvesters = new List<Harvester>();
    List<Provider> providers = new List<Provider>();

    public string RegisterHarvester(List<string> arguments)
    {
        if (arguments[1] == "Sonic")
        {
            var id = arguments[2];
            var oreOutput = double.Parse(arguments[3]);
            var energyRequirement = double.Parse(arguments[4]);
            var sonicFactor = double.Parse(arguments[5]);

            harvesters.Add(new SonicHarvester(id, oreOutput, energyRequirement, sonicFactor));
        }
        else
        {
            //harvesters.Add(new HammerHarvester());
        }

        return "Successfully registered Sonic Harvester ";
    }
    string RegisterProvider(List<string> arguments)
    {
        return ";";
    }
    string Day()
    {
        return ";";
    }
    string Mode(List<string> arguments)
    {
        return ";";
    }
    string Check(List<string> arguments)
    {
        return ";";
    }
    public string ShutDown()
    {
        return "System Shutdown";
    }
}
