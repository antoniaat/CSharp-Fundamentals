﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Factories
{
    public class StorageFactory
    {
        public Storage CreateStorage(string type, string name)
        {
            Storage newPStorage = null;

            switch (type)
            {
                case "AutomatedWarehouse":
                    newPStorage = new AutomatedWarehouse(name);
                    break;
                case "DistributionCenter":
                    newPStorage = new DistributionCenter(name);
                    break;
                case "Warehouse":
                    newPStorage = new Warehouse(name);
                    break;
                default:
                    throw new InvalidOperationException($"Invalid storage type!");
            }

            return newPStorage;
        }
    }
}
