﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StorageMaster.Factories;

namespace StorageMaster.Core
{
    public class StorageMaster
    {
        public List<Storage> StorageRegistry;
        public List<Product> ProductsPool;
        public Vehicle CurrentVehicle = null;

        public StorageMaster()
        {
            StorageRegistry = new List<Storage>();
            ProductsPool = new List<Product>();
        }

        public string AddProduct(string type, double price)
        {
            try
            {
                var productFactory = new ProductFactory();
                var product = productFactory.CreateProduct(type, price);
                ProductsPool.Add(product);
            }

            catch (Exception ex)
            {
                return $"ERROR: {ex.Message}";
            }

            return $"Added {type} to pool";
        }

        public string RegisterStorage(string type, string name)
        {
            try
            {
                var storageFactory = new StorageFactory();
                var storage = storageFactory.CreateStorage(type, name);
                StorageRegistry.Add(storage);
            }

            catch (Exception ex)
            {
                return $"ERROR: {ex.Message}";
            }

            return $"Registered {name}";
        }

        public string SelectVehicle(string storageName, int garageSlot)
        {
            var vehicle = StorageRegistry.Where(x => x.Name == storageName).FirstOrDefault();
            var vee = vehicle.GetVehicle(garageSlot);

            //var vehicle = StorageRegistry.Select(x => x.Name == storageName).First();

            //var vehicle2 = vehicle.GetVehicle(garageSlot);

            CurrentVehicle = vee;

            return $"Selected {CurrentVehicle.GetType().Name}";
        }

        public string LoadVehicle(IEnumerable<string> productNames)
        {
            int loadedProductsCount = 0;
            foreach (var product in productNames)
            {
                if (ProductsPool.Count(x => x.GetType().Name == product) == 0)
                {
                    throw new InvalidOperationException($"{product} is out of stock!");
                }

                ProductsPool.Remove(ProductsPool.Last(x => x.GetType().Name == product));

                CurrentVehicle.LoadProduct(ProductsPool.First(x => x.GetType().Name == product));
                loadedProductsCount++;
            }

            return
                $"Loaded {loadedProductsCount}/{productNames.Count()}" +
                              $" products into {CurrentVehicle.GetType().Name}";
        }

        public string SendVehicleTo(string sourceName, int sourceGarageSlot, string destinationName)
        {
            if (StorageRegistry.Count(x => x.Name == sourceName) == 0)
            {
                throw new InvalidOperationException($"Invalid source storage!");
            }

            if (StorageRegistry.Count(x => x.Name == destinationName) == 0)
            {
                throw new InvalidOperationException($"Invalid destination storage!");
            }

            var sourceStorageVehicle = StorageRegistry.Where(n => n.Name == sourceName)
                .FirstOrDefault();

            var destionationStorage = StorageRegistry.Where(n => n.Name == destinationName)
                .FirstOrDefault();

            int destinationGarageSlot = sourceStorageVehicle.SendVehicleTo(sourceGarageSlot, destionationStorage);

            var vehicleType = destionationStorage.GarageArray[destinationGarageSlot].GetType().Name;

            return $"Sent {vehicleType} to {destinationName} (slot {destinationGarageSlot})";
        }

        public string UnloadVehicle(string storageName, int garageSlot)
        {
            var storage = StorageRegistry
                .FirstOrDefault(n => n.Name == storageName);

            var unloadedProductsCount = storage.UnloadVehicle(garageSlot);

            return $"Unloaded {unloadedProductsCount}/{storage.Products.Count} products at {storageName}";
        }

        public string GetStorageStatus(string storageName)
        {
            var storage = StorageRegistry
                .FirstOrDefault(n => n.Name == storageName);
            var count = storage.Products.Count;

            var result = new StringBuilder();

            var groupedStorage = storage.Products
                .GroupBy(u => u.GetType().Name)
                .Select(grp => grp.ToList())
                .ToList();

            foreach (var product in groupedStorage.OrderByDescending(x => x.Count).ThenBy(x => x.GetType().Name))
            {
                //foreach (var kvp in product.OrderByDescending(x => x.Count).ThenBy(x => x.GetType().Name))
                //{

                //}

                //if (product.Count == 0)
                //{
                //    ProductsPool.First(x => x.GetType().Name == product);
                //}
            }

            return result.ToString();
        }

        public string GetSummary()
        {
            var sb = new StringBuilder();
            foreach (var storage in StorageRegistry.OrderByDescending(x => x.Products.Sum(y => y.Price)))
            {
                sb.AppendLine(storage.ToString());
            }

            return sb.ToString();
        }
    }
}

