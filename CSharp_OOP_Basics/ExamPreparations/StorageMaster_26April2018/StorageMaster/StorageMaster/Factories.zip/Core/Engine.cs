﻿namespace StorageMaster.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Engine
    {
        private bool isRunning;
        private readonly StorageMaster manager;

        public Engine(StorageMaster manager)
        {
            this.manager = manager;
        }

        public void Run()
        {
            this.isRunning = true;

            while (this.isRunning)
            {
                string inputLine = Console.ReadLine();
                List<string> inputParams = inputLine.Split().ToList();

                string commandResult = String.Empty;
                try
                {
                    commandResult = this.DispatchCommand(inputParams);
                }
                catch (Exception ex)
                {
                    commandResult = "ERROR" + $"{ex.Message}";
                }

                Console.WriteLine(commandResult);
            }
        }

        private string DispatchCommand(List<string> inputParams)
        {
            string command = inputParams[0];
            inputParams.RemoveAt(0);

            string result = null;

            switch (command)
            {
                case "AddProduct":
                    result = this.manager.AddProduct(inputParams[0], double.Parse(inputParams[1]));
                    break;
                case "RegisterStorage":
                    result = this.manager.RegisterStorage(inputParams[0], inputParams[1]);
                    break;
                case "SelectVehicle":
                    result = this.manager.SelectVehicle(inputParams[0], int.Parse(inputParams[1]));
                    break;
                case "LoadVehicle":
                    result = this.manager.LoadVehicle(inputParams);
                    break;
                case "SendVehicleTo":
                    result = this.manager.SendVehicleTo(inputParams[0], int.Parse(inputParams[1]), inputParams[2]);
                    break;
                case "UnloadVehicle":
                    result = this.manager.UnloadVehicle(inputParams[0], int.Parse(inputParams[1]));
                    break;
                case "GetStorageStatus":
                    result = this.manager.GetStorageStatus(inputParams[0]);
                    break;
                case "END":
                    Console.WriteLine(this.manager.GetSummary());
                    this.isRunning = false;
                    break;
            }

            return result;
        }
    }
}