﻿using StorageMaster.Core;

public class StartUp
{
    public static void Main()
    {
        var manager = new StorageMaster.Core.StorageMaster();
        var engine = new Engine(manager);
        engine.Run();
    }
}


