﻿public class SolidStateDrive  : Product
{
    public SolidStateDrive(double price)
        : base(price)
    {
        this.Weight = 0.2;
    }
}