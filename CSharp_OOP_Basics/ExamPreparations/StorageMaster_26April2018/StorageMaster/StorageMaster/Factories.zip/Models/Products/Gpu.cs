﻿public class Gpu : Product
{
    public Gpu(double price) 
        : base(price)
    {
        this.Weight = 0.7;
    }
}