﻿using System;

public abstract class Product
{
    private double price;
    private double weight;

    protected Product(double price)
    {
        this.price = price;
    }

    protected Product(double price, double weight)
    {
        this.Price = price;
        this.Weight = weight;
    }

    public double Weight{ get; set; }

    public double Price
    {
        get => this.price;
        set
        {
            if (value < 0)
            {
                throw new InvalidOperationException($"Price cannot be negative!");
            }

            this.price = value;
        }
    }
}
