﻿public class Ram : Product
{
    public Ram(double price)
        : base(price)
    {
        this.Weight = 0.1;
    }
}