﻿public class DistributionCenter : Storage
{
    public DistributionCenter(string name)
        : base(name)
    {
        this.Name = name;
        this.Capacity = 2;
        this.GarageSlots = 5;
        this.Vehicles = new Vehicle[] { new Van(), new Van(), new Van() };
    }
}