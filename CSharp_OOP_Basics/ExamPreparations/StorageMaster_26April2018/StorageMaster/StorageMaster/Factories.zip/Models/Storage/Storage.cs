﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class Storage
{
    private string name;
    private int capacity;
    private int garageSlots;
    private bool isFull;
    private Vehicle[] garage;
    private List<Product> products;
    private IEnumerable<Vehicle> vehicles;

    protected Storage(string name)
    {
        this.Name = name;
        this.Capacity = capacity;
        this.GarageSlots = garageSlots;
        this.garage = new Vehicle[Capacity];
        this.products = new List<Product>();
        this.IsFull = isFull;
    }

    public IReadOnlyCollection<Vehicle> Garage => this.garage;

    public Vehicle[] GarageArray => this.garage.ToArray();

    public IReadOnlyCollection<Product> Products => this.products.AsReadOnly();

    public IEnumerable<Vehicle> Vehicles { get; set; }

    public bool IsFull
    {
        get => this.isFull;
        private set
        {
            //Returns true if the sum of the products’ weights is equal to or larger than the storage capacity (calculated property)
            if (products.Sum(p => p.Weight) >= this.Capacity)
            {
                value = true;
            }

            value = false;
            this.isFull = value;
        }
    }

    public int GarageSlots { get; set; }

    public int Capacity { get; set; }

    public string Name { get; set; }

    public Vehicle GetVehicle(int garageSlot)
    {
        if (garageSlot >= this.GarageSlots)
        {
            throw new InvalidOperationException($"Invalid garage slot!");
        }

        if (this.GarageSlots == 0)
        {
            throw new InvalidOperationException($"No vehicle in this garage slot!");
        }

        var res = garage[garageSlot];
        return res;
    }

    public int SendVehicleTo(int garageSlot, Storage deliveryLocation)
    {
        Vehicle vehicle = this.GetVehicle(garageSlot);

        if (!this.garage.Any(x => x == null))
        {
            throw new InvalidOperationException($"No room in garage!");
        }

        var index = Array.IndexOf(this.garage, this.garage.First(x => x == null));
        this.garage[index] = vehicle;
        return index;
    }

    public int UnloadVehicle(int garageSlot)
    {
        if (IsFull)
        {
            throw new InvalidOperationException($"Storage is full!");
        }

        var vehicle = this.GetVehicle(garageSlot);

        int unloadedProducts = 0;

        while (vehicle.IsEmpty || this.IsFull)
        {
            var product = vehicle.Unload();
            this.products.Add(product);
            unloadedProducts++;
        }

        return unloadedProducts;
    }

    public override string ToString()
    {
        var sb = new StringBuilder();
        sb.AppendLine($"{this.Name}:");
        sb.AppendLine($"Storage worth: ${this.products.Sum(x=>x.Price):F2}");
        return sb.ToString();
    }
}
