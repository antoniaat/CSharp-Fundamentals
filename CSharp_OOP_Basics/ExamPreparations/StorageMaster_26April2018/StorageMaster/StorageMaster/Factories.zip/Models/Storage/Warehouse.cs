﻿public class Warehouse  : Storage
{
    public Warehouse(string name)
        : base(name)
    {
        this.Capacity = 10;
        this.GarageSlots = 10;
        this.Vehicles = new Vehicle[] { new Semi(), new Semi(), new Semi()};
    }
}