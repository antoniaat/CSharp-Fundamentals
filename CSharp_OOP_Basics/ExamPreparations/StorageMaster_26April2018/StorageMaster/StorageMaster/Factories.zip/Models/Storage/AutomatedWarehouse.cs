﻿public class AutomatedWarehouse : Storage
{
    public AutomatedWarehouse(string name)
        : base(name)
    {
        this.Capacity = 1;
        this.GarageSlots = 2;
        this.Vehicles = new Vehicle[] { new Truck() };
    }
}