﻿using System;
using System.Collections.Generic;
using System.Linq;

public abstract class Vehicle
{
    private int capacity;
    private List<Product> trunk;
    private bool isFull;
    private bool isEmpty;

    protected Vehicle(int capacity)
    {
        this.Capacity = capacity;
        this.trunk = new List<Product>();
        this.IsFull = isFull;
        this.IsEmpty = isEmpty;
    }


    public bool IsEmpty
    {
        get => this.isEmpty;
        set
        {
            if (trunk.Count == 0)
            {
                value = true;
            }

            value = false;
            this.isEmpty = value;
        }
    }

    public bool IsFull
    {
        get => this.isEmpty;
        set
        {
            if (trunk.Count > 0)
            {
                value = true;
            }

            value = false;
            this.isFull = value;
        }
    }

    protected IReadOnlyCollection<Product> Trunk => this.trunk.AsReadOnly();

    public int Capacity { get; protected set; }

    public void LoadProduct(Product product)
    {
        if (isFull)
        {
            throw new InvalidOperationException($"Vehicle is full!");
        }

        trunk.Add(product);
    }

    public Product Unload()
    {
        if (trunk.Count == 0)
        {
            throw new InvalidOperationException($"No products left in vehicle!");
        }

        var lastProductInTrunk = trunk.Last();
        trunk.Remove(lastProductInTrunk);
        return lastProductInTrunk;
    }
}