﻿public class Truck  : Vehicle
{
    private const int capacity = 5;

    public Truck() : base(capacity)
    {
    }
}