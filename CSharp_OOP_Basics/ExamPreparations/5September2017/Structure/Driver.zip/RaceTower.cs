﻿internal class RaceTower
{
    //void SetTrackInfo(int lapsNumber, int trackLength)
    //{
    //    //TODO: Add some logic here …
    //}
    //void RegisterDriver(List<string> commandArgs)
    //{
    //    //TODO: Add some logic here …
    //}

    //void DriverBoxes(List<string> commandArgs)
    //{
    //    //TODO: Add some logic here …
    //}

    //string CompleteLaps(List<string> commandArgs)
    //{
    //    //TODO: Add some logic here …
    //}

    //string GetLeaderboard()
    //{
    //    //TODO: Add some logic here …
    //}

    //void ChangeWeather(List<string> commandArgs)
    //{
    //    //TODO: Add some logic here …
    //}
}