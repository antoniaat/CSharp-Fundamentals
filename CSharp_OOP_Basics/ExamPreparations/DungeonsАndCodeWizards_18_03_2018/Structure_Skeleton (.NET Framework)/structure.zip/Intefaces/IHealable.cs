﻿using DungeonsAndCodeWizards.Models.Characters;

namespace DungeonsAndCodeWizards.Intefaces
{
    public interface IHealable
    {
        void Heal(Character character);
    }
}
