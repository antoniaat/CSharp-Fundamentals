﻿using DungeonsAndCodeWizards.Models.Characters;

namespace DungeonsAndCodeWizards.Intefaces
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
