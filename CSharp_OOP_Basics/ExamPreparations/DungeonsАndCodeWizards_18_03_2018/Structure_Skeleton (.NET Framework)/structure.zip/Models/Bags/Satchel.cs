﻿namespace DungeonsAndCodeWizards.Model.Bags
{
    public class Satchel : Bag
    {
        public Satchel(int capacity)
            : base(capacity)
        {
            this.Capacity = 20;
        }
    }
}
