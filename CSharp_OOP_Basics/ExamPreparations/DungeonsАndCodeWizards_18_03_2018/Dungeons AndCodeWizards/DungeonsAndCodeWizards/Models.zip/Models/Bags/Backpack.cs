﻿public class Backpack : Bag
{
    public Backpack(int capacity) 
        : base(capacity)
    {
        this.Capacity = 100;
    }
}
